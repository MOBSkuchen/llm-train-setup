from typing import Tuple

# types which can be shown directly in the UI without any extra nesting
KNOWN_TYPE_ANNOTATIONS = [int, float, bool, str, Tuple[str, ...]]
