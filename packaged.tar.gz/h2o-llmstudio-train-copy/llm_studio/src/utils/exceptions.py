class LLMDataException(Exception):
    pass


class LLMModelException(Exception):
    pass


class LLMAugmentationsException(Exception):
    pass


class LLMMetricException(Exception):
    pass


class LLMTrainingException(Exception):
    pass


class LLMResourceException(Exception):
    pass
